# Notes - Android APK Project (Native Studio Ready)

This is the full Android Studio project for **Notes - 10th SSLC Study Companion**.

## How to Build the `.apk` file:

### Option 1: In Android Studio (Easiest)
1. Open Android Studio.
2. Select **Open an Existing Project** and choose this unzipped folder.
3. Wait for Gradle sync to complete.
4. Click **Build** menu > **Build Bundle(s) / APK(s)** > **Build APK(s)**.
5. Android Studio will generate `app-debug.apk` ready to install on any Android phone!

### Option 2: In Command Line / Terminal
```bash
# On Linux / macOS:
./gradlew assembleDebug

# On Windows:
gradlew.bat assembleDebug
```
The compiled APK will be located at:
`app/build/outputs/apk/debug/app-debug.apk`

Transfer `app-debug.apk` to your Android device, tap it, and tap **Install**!
